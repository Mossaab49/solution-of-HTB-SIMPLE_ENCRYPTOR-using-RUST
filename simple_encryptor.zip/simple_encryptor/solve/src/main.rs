use std::fs::File;
use std::io::Read;

//C functions [srand(), rand()] ----------------------------------

unsafe extern "C" {
    fn c_srand(seed: u32);
    fn c_rand() -> i32;
}
// ------------------------------------------------------

fn main() {
    //reading the encrypted flag ----------------------------------

    let mut file = File::open("../flag.enc").unwrap();

    let mut buf: [u8; 4] = [0u8; 4];
    file.read_exact(&mut buf).unwrap();
    let seed = u32::from_le_bytes(buf);

    let mut encrypted_flag = Vec::new();
    file.read_to_end(&mut encrypted_flag).unwrap();
    //----------------------------------------------------------

    unsafe {
        //generate the srand() ----------------------------------

        c_srand(seed);
        //----------------------------------------------------------

        //inverse the encryption ----------------------------------

        let mut decrypted_flag = Vec::new();

        for byte in encrypted_flag {
            let xor_nbr = (c_rand() & 0xff) as u8;
            let shift_nbr = c_rand() as u32 & 7;

            let flag = byte.rotate_right(shift_nbr);
            let flag = format!("{:02x}", flag ^ xor_nbr);

            decrypted_flag.push(flag);
        }
        //----------------------------------------------------------

        //print the flag ----------------------------------
        let bytes: Vec<u8> = decrypted_flag
            .iter()
            .map(|s| u8::from_str_radix(s, 16).unwrap())
            .collect();

        let final_flag = String::from_utf8_lossy(&bytes);
        println!("Flag: {}", final_flag);
        //----------------------------------------------------------
    }
}
