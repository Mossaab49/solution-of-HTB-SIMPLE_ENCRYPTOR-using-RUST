#include <stdlib.h>

void c_srand(unsigned int seed) {
    srand(seed);
}

int c_rand() {
    return rand();
}
