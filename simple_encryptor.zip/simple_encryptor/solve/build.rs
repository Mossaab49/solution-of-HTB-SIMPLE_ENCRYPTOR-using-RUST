fn main() {
    cc::Build::new().file("src/rng.c").compile("rng");
}
